"""Dialect registry and the public fragment renderers (spec 8.3, 18 R6; layer 12).

Resolution order for ``dialect="x"`` (spec 8.3): the native profile if one is registered;
else the sqlglot bridge if it is installed; else ``FL504 unknown dialect``.
"""

from __future__ import annotations

import dataclasses
import importlib
from collections.abc import Callable, Mapping, Sequence
from types import MappingProxyType, ModuleType
from typing import Any, Literal

from factlang.ir import ProbePlan
from factlang.semantics.filters import FilterExpr
from factlang.semantics.refs import EdgeRef, TableRef
from factlang.sql.fragment import JoinEdge, RenderedFragment, lower_filter, lower_join
from factlang.sql.printer import Printer, render
from factlang.sql.probe import LiteralStyle, RenderedProbe, RenderError
from factlang.sql.profile import DialectProfile
from factlang.sql.profiles import BUILTIN_PROFILES

# FactLang dialect name -> sqlglot dialect name (used to cross-check rendered SQL).
SQLGLOT_NAMES: Mapping[str, str] = MappingProxyType(
    {
        "bigquery": "bigquery",
        "snowflake": "snowflake",
        "redshift": "redshift",
        "postgres": "postgres",
        "duckdb": "duckdb",
        "databricks": "databricks",
        "clickhouse": "clickhouse",
        "tsql": "tsql",
        "mysql": "mysql",
        "oracle": "oracle",
        "trino": "trino",
    }
)

_PROFILES: dict[str, DialectProfile] = {}


def register_profile(profile: DialectProfile, *, replace: bool = False) -> None:
    """Register a native profile under ``profile.name``; a duplicate raises unless ``replace``."""
    if not isinstance(profile, DialectProfile):
        raise TypeError(f"expected a DialectProfile, got {profile!r}")
    if profile.name in _PROFILES and not replace:
        raise ValueError(f"dialect profile {profile.name!r} is already registered")
    _PROFILES[profile.name] = profile


def get_profile(name: str) -> DialectProfile | None:
    return _PROFILES.get(name)


def native_dialects() -> list[str]:
    """Names of every registered native profile, sorted."""
    return sorted(_PROFILES)


def _bridge() -> ModuleType | None:
    """The sqlglot bridge module, or ``None`` when sqlglot (or the bridge) is unavailable."""
    try:
        importlib.import_module("sqlglot")
        return importlib.import_module("factlang.sql.sqlglot_bridge")
    except ModuleNotFoundError as exc:
        # only a missing sqlglot or bridge means "not installed"; any other import error
        # inside the bridge is a real bug and propagates
        if exc.name is not None and (
            exc.name == "sqlglot"
            or exc.name.startswith("sqlglot.")
            or exc.name == "factlang.sql.sqlglot_bridge"
        ):
            return None
        raise


def _unknown(dialect: str) -> RenderError:
    return RenderError(
        f"FL504 unknown dialect {dialect!r}; native dialects: {', '.join(native_dialects())}; "
        "for any other sqlglot dialect: pip install factlang[sqlglot]"
    )


def renderer_for(
    dialect: str, *, prefer: Literal["native", "sqlglot"] = "native"
) -> Callable[[ProbePlan], RenderedProbe]:
    """The renderer for ``dialect`` (spec 8.3 resolution order); ``FL504`` when none exists.

    ``prefer="sqlglot"`` forces the bridge (used by tests to cross-check native output).
    The bridge is expected to expose ``render(plan, dialect) -> RenderedProbe``.
    """
    if prefer not in ("native", "sqlglot"):
        raise ValueError(f"prefer must be 'native' or 'sqlglot', got {prefer!r}")
    profile = _PROFILES.get(dialect)
    if prefer == "native" and profile is not None:
        native = profile

        def render_native(plan: ProbePlan) -> RenderedProbe:
            return render(plan, native)

        return render_native
    bridge = _bridge()
    if bridge is None:
        if prefer == "sqlglot":
            raise RenderError(
                "FL504 sqlglot bridge not installed (pip install factlang[sqlglot]); "
                f"cannot render {dialect!r} through it"
            )
        raise _unknown(dialect)
    if not bridge.supports_dialect(dialect):
        raise _unknown(dialect)
    bridge_render: Any = bridge.render

    def render_bridged(plan: ProbePlan) -> RenderedProbe:
        result: RenderedProbe = bridge_render(plan, dialect)
        return result

    return render_bridged


def literal_style_for(dialect: str) -> LiteralStyle:
    """The inline-literal spellings of ``dialect``, resolved as :func:`renderer_for` resolves
    it: the native profile registered under exactly that name, else the dialect the sqlglot
    bridge resolves it to. A dialect neither knows gets ANSI spellings with no doubled-quote
    form, so a string holding ``'`` is refused (fail closed).

    A native profile whose name is also a dialect sqlglot knows keeps ``''`` only when that
    dialect's lexer reads it as a quote too: a custom profile registered as ``hive`` cannot
    switch doubling on for a lexer that has none (fail closed)."""
    profile = _PROFILES.get(dialect) if isinstance(dialect, str) else None
    bridge = _bridge()
    if profile is not None:
        style_ = profile.literal_style
        if style_.doubled_quote_escape and bridge is not None:
            lexer: bool | None = bridge.lexer_doubles_quote(dialect)
            if lexer is False:
                return dataclasses.replace(style_, doubled_quote_escape=False)
        return style_
    if bridge is not None:
        style: LiteralStyle | None = bridge.literal_style(dialect)
        if style is not None:
            return style
    return _UNKNOWN_STYLE


_UNKNOWN_STYLE = LiteralStyle(doubled_quote_escape=False)


def _profile(dialect: str | DialectProfile) -> DialectProfile:
    if isinstance(dialect, DialectProfile):
        return dialect
    profile = _PROFILES.get(dialect)
    if profile is None:
        raise _unknown(dialect)
    return profile


def _fragment_bridge(
    dialect: str | DialectProfile, prefer: Literal["native", "sqlglot"]
) -> ModuleType | None:
    """The bridge when a fragment for ``dialect`` goes through it (spec 8.3 order), else None."""
    if prefer not in ("native", "sqlglot"):
        raise ValueError(f"prefer must be 'native' or 'sqlglot', got {prefer!r}")
    if isinstance(dialect, DialectProfile):
        if prefer == "native":
            return None
        name = dialect.name
    else:
        name = dialect
    if prefer == "native" and name in _PROFILES:
        return None
    bridge = _bridge()
    if bridge is None:
        if prefer == "sqlglot":
            raise RenderError(
                "FL504 sqlglot bridge not installed (pip install factlang[sqlglot]); "
                f"cannot render {name!r} through it"
            )
        raise _unknown(name)
    if not bridge.supports_dialect(name):
        raise _unknown(name)
    return bridge


def _fragment(text: str, printer: Printer, profile: DialectProfile) -> RenderedFragment:
    if ";" in text:
        raise RenderError(f"FL500 rendered fragment failed the guard: {text[:80]!r}")
    return RenderedFragment(text, printer.params, profile.name, profile.tier)


def render_filter(
    filter: FilterExpr,
    *,
    dialect: str | DialectProfile,
    table: TableRef | None = None,
    alias: str | None = None,
    param_prefix: str = "p",
    prefer: Literal["native", "sqlglot"] = "native",
) -> RenderedFragment:
    """A resolved filter as a bindable boolean expression (R6), columns qualified by ``alias``.

    ``table`` (optional) is checked against the dialect's identifier rules and table-part
    limit (FL502/FL505). Parameters are named ``<param_prefix>1``, …. A dialect without a
    native profile (or ``prefer="sqlglot"``) goes through the sqlglot bridge.
    """
    bridge = _fragment_bridge(dialect, prefer)
    if bridge is not None:
        # a DialectProfile object is threaded through as given (never swapped)
        node = lower_filter(filter, alias, param_prefix=param_prefix)
        bridged: RenderedFragment = bridge.render_filter_fragment(node, dialect, table=table)
        return bridged
    profile = _profile(dialect)
    printer = Printer(profile)
    if table is not None:
        printer.table(table)
    text = printer.expression(lower_filter(filter, alias, param_prefix=param_prefix))
    return _fragment(text, printer, profile)


def render_join(
    edges: Sequence[EdgeRef | JoinEdge],
    dialect: str | DialectProfile,
    *,
    filters: Mapping[TableRef, FilterExpr] | None = None,
    aliases: Mapping[TableRef, str] | None = None,
    param_prefix: str = "p",
    prefer: Literal["native", "sqlglot"] = "native",
) -> RenderedFragment:
    """``FROM a JOIN b ON … [WHERE …]`` for a join path (R6), bindable, never executed here.

    The left-most table's filter is the ``WHERE``; every other table's filter is ANDed into
    the ``ON`` of the join that brings it in (see :func:`~factlang.sql.fragment.lower_join`).
    A dialect without a native profile (or ``prefer="sqlglot"``) goes through the bridge.
    """
    bridge = _fragment_bridge(dialect, prefer)
    from_, where = lower_join(edges, filters, aliases, param_prefix=param_prefix)
    if bridge is not None:
        bridged: RenderedFragment = bridge.render_join_fragment(from_, where, dialect)
        return bridged
    profile = _profile(dialect)
    printer = Printer(profile)
    text = "FROM " + printer.from_clause(from_)
    if where is not None:
        text += " WHERE " + printer.expression(where)
    return _fragment(text, printer, profile)


for _p in BUILTIN_PROFILES:
    register_profile(_p)


__all__ = [
    "SQLGLOT_NAMES",
    "get_profile",
    "literal_style_for",
    "native_dialects",
    "register_profile",
    "render_filter",
    "render_join",
    "renderer_for",
]
